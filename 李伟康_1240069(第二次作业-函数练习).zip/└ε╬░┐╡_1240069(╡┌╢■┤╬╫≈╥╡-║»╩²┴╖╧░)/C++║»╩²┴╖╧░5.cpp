/*
******************************************
1.	����:�����������̵ꡣ
2.	Date		Name	Create/Correct
	2013.3.23	��ΰ��	Create		
******************************************
*/
#include <iostream>
#include <windows.h>
#include <string>
int system(const char *string);//��������
using namespace std;
class Shop
{
private:
	int number;
	int price;
	string name;
	string kind;
	string place;
	string describtion;
public:
	void set_number();
	void show_number();
	void set_name();
	void show_name();
	void set_kind();
	void show_kind();
	void set_place();
	void show_place();
	void set_price();
	void show_price();
	void set_describtion();
	void show_describtion();
	string change_name(string name);
	int change_price(int price);
	void change_name();
	void change_price();
};
void Shop::set_number()
{
	cout<<"Please input the number of products:";
	cin>>number;
}
void Shop::show_number()
{
	cout<<"The number of the product:";
	cout<<number<<endl;
}

void Shop::set_name()
{
	cout<<"Please input the name of products:";
	getline(cin,name,'\n');
}
void Shop::show_name()
{
	cout<<"The name of the product:";
	cout<<name<<endl;
}

void Shop::set_kind()
{
	cout<<"Please input the kind of products:";
	getline(cin,kind,'\n');
}
void Shop::show_kind()
{
	cout<<"The kind of the product:";
	cout<<kind<<endl;
}

void Shop::set_place()
{
	cout<<"Please input the place of products:";
	getline(cin,place,'\n');
}
void Shop::show_place()
{
	cout<<"The place of the product:";
	cout<<place<<endl;
}

void Shop::set_price()
{
	cout<<"Please input the price of products:";
	cin>>price;
}
void Shop::show_price()
{
	cout<<"The price of the product:";
	cout<<price<<endl;
}

void Shop::set_describtion()
{
	cout<<"Please input the describtion of products:";
	getline(cin,describtion,'\n');
}
void Shop::show_describtion()
{
	cout<<"The describtion of the product:";
	cout<<describtion<<endl;
}

//string change_name(string &name)
void Shop::change_name()
{
	cout<<"The name of the product:";
	cout<<name<<endl;
	fflush(stdin);
	cout<<"Please input the new information:";
	getline(cin,name,'\n');
}
//int change_price(int &price)
void Shop::change_price()
{
	cout<<"The price of the product:";
	cout<<price<<endl;
	cout<<"Please input the new information:";
	cin>>price;
}

int main()
{
	int choose;
	int i;
	char choos;
	int chos;
	i=0;
	choose=0;
	choos=0;
	chos=0;
	Shop *shop[2];
//�����Ʒ�����Ϣ
	for(i=0;i<2;i++)
	{
		cout<<"***ע�������ʽһ��Ҫ��ȷ***\n";
		cout<<"The shop"<<" ["<<i+1<<"]"<<"'s information:\n";
		shop[i]=new Shop;
	  	shop[i]->set_number();
		shop[i]->set_price();
		fflush(stdin);
		shop[i]->set_name();
		shop[i]->set_kind();
		shop[i]->set_place();
		shop[i]->set_describtion();
		fflush(stdin);
		cout<<endl;
		system("cls");
	}

//�鿴���޸Ĳ�Ʒ��Ϣ
	system("cls");
start:
	cout<<"����welcome to our online shop����\n";
	cout<<"******1.product_1               ******\n";
	cout<<"******2.product_2               ******\n";
	cout<<"******3.exit                    ******\n";
	cout<<"**************************************\n";
	cout<<"Please input the number of you want to see:\n";
	cin>>choose;
start1:
	if(choose-1==0)
	{
		system("cls");
		cout<<"������shop[0]'s information ������\n";
		shop[0]->show_number();
		shop[0]->show_price();
		shop[0]->show_name();
		shop[0]->show_kind();
		shop[0]->show_place();
		shop[0]->show_describtion();
		cout<<"******************************************\n\n";
//�޸Ĳ�Ʒ��Ϣ
		cout<<"Do you want to change the news of the product?(y/n)\n";
		cin>>choos;
		if(choos=='y'||choos=='Y')
		{
			system("cls");
start2:
			cout<<"������CHOICES������\n";	
			cout<<"******1.change name. ******\n";
			cout<<"******2.change price.******\n";
			cout<<"******3.exit.        ******\n";
			cout<<"***************************\n";
			cout<<"please input your choice:\n";
			cin>>chos;
			switch(chos)
			{
				case 1:	//cout<<change_name(shop[0]->name);
						//shop[0]->change_name(shop[0]->name);
						shop[0]->change_name();
						cout<<"The new information of the shop[1]\n";
						goto start1;
						break;

				case 2:	//cout<<change_price(shop[0]->price);
						//shop[0]->change_price(shop[0]->price);
						shop[0]->change_price();
						cout<<"The new information of the shop[1]\n";
						goto start1;
						break;

				case 3:	goto start1;

				default:cout<<"��������,����������:\n";
						Sleep(2000);
						system("cls");
						goto start2;
			}
		}
	}
	else if(choose-1==1)
	{
start3:
		system("cls");
		cout<<"������shop[0]'s information ������\n";
		shop[1]->show_number();
		shop[1]->show_price();
		shop[1]->show_name();
		shop[1]->show_kind();
		shop[1]->show_place();
		shop[1]->show_describtion();
		cout<<"******************************************\n\n";
		
//�޸Ĳ�Ʒ��Ϣ
		cout<<"Do you want to change the news of the product?(y/n)\n";
		cin>>choos;
		if(choos=='y'||choos=='Y')
		{
			system("cls");
start4:
			cout<<"������CHOICES������\n";	
			cout<<"******1.change name. ******\n";
			cout<<"******2.change price.******\n";
			cout<<"******3.exit.        ******\n";
			cout<<"***************************\n";
			cout<<"please input your choice:\n";
			cin>>chos;
			switch(chos)
			{
				case 1://cout<<change_name(shop[1]->name);
						//shop[1]->change_name(shop[1]->name);
						shop[1]->change_name();
						cout<<"The new information of the shop[2]\n";
						goto start3;
						break;

				case 2://cout<<change_price(shop[1]->price);
						//shop[1]->change_price(shop[1]->price);
						shop[1]->change_price();
						cout<<"The new information of the shop[2]\n";
						goto start3;
						break;

				case 3:	goto start3;

				default:cout<<"��������,����������:\n";
						Sleep(2000);
						system("cls");
						goto start4;
			}
		}
	}
	else if(choose-1==2)
	{
		goto end;
	}
	else
	{
		cout<<"��������,����������:\n";
		Sleep(2000);
		system("cls");
		goto start;
	}
	
	for(i=0;i<2;i++)
	{
		delete shop[i];
	}
end:
	return 0;
}


