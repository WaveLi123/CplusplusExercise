#include <iostream>
#include <windows.h>
#include <string>
int system(const char *string);//��������
using namespace std;
class Date
{
	friend class Product;//��Ԫ��
private:
	int hour;
	int minute;
	int second;
};

class Product
{
private:
	int number;
	float price;
	string name;
	string kind;
	string place;
	string describtion;
public:
	static int count_number;
	static float sum_price;
	void set_number();
	void show_number();
	void set_name();
	void show_name();
	void set_kind();
	void show_kind();
	void set_place();
	void show_place();
	void set_price();
	void show_price();
	void set_describtion();
	void show_describtion();
	void get_date(Date *);
	void show_date(Date *);
	void change_name();
	void change_price();
	float sum_of_price();
};
