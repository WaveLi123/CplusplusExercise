#include "online_shop.h"
#include <iostream>
#include <windows.h>
#include <string>
using namespace std;
//��������
int system(const char *string);
void medu();

//��̬��Ա�ĳ�ʼ��
int Product::count_number=0;
float Product::sum_price=0.0;

//����ȫ�ֱ���
int i=0;
Product *produuct[1000];
Date *date[1000];

int main()
{
	char c;
	c='n';

//�����Ʒ�����Ϣ
	while(c!='y'&&c!='Y')
	{
		cout<<"***ע�������ʽһ��Ҫ��ȷ***\n";
		cout<<"The produuct"<<" ["<<++i<<"]"<<"'s information:\n";
		produuct[i]=new Product;
		date[i]=new Date;
	  	produuct[i]->set_number();
		produuct[i]->set_price();
		fflush(stdin);
		produuct[i]->set_name();
		produuct[i]->set_kind();
		produuct[i]->set_place();
		produuct[i]->set_describtion();
		fflush(stdin);
		produuct[i]->get_date(date[i]);
		cout<<endl<<endl;
		cout<<"Now you have "<<++Product::count_number<<" products.\n";
		cout<<"Now the sum of price is "<< produuct[i]->sum_of_price()<<".\n"<<endl;
		cout<<"Do you want to quit?(y/n)\n";
		cin>>c;
		system("cls");
	}
	medu ();

	return 0;
}
///////////////////////���˵���������///////////////////////
void medu_2();//��������
void medu()
{
	char choose;
	choose=0;
start:
	cout<<"�������CHOICES��������\n";
	cout<<"*[A]: Add a product             *\n";
	cout<<"*[D]: Display all products      *\n";
	cout<<"*[Q]: Quit                      *\n";
	cout<<"*********************************\n";
	cout<<"Please input your chice:\n";
	cin>>choose;

	if(choose=='a'||choose=='A')
	{
		system("cls");
		main();
	}

	else if(choose=='s'||choose=='S')
	{
		system("cls");
	}

	else if(choose=='d'||choose=='D')
	{
		system("cls");
		medu_2();
	}

	else if(choose=='Q'||choose=='q')
	{
		exit(0);
	}

	else 
	{
		cout<<"The choice you put is wrong,please input again.\n";
		Sleep(3000);
		system("cls");
		goto start;
	}
}
//////////////���˵�����///////////////
void medu_3(int x);//��������
void medu();//��������
void medu_2()
{
	int j;
	int choose_1;
	char choose_2;
	choose_1=0;
	choose_2=0;
start2:
	cout<<"��PRODUCTS'S INFORMATION��\n";
	for(j=1;j<=i;j++)
	{
		cout<<"*"<<j<<".product["<<j<<"]            *"<<endl;
	}
	cout<<"*"<<i+1<<".Back medu             *"<<endl;
	cout<<"*"<<i+2<<".Quit                  *"<<endl;
	cout<<"**************************\n";
	cout<<"Please input the number of product:\n";
	cin>>choose_1;
	for(j=1;j<=i;j++)
	{
		if(choose_1==j)
		{
			system("cls");
			cout<<"������Product["<<j<<"]'s information ������\n";
			produuct[j]->show_number();
			produuct[j]->show_price();
			produuct[j]->show_name();
			produuct[j]->show_kind();
			produuct[j]->show_place();
			produuct[j]->show_describtion();
			produuct[j]->show_date(date[j]);
			cout<<"******************************************\n\n";
			cout<<"Do you want to change the news of the product?(y/n)\n";
			cin>>choose_2;
			if(choose_2=='y'||choose_2=='Y')
			{
				system("cls");
				medu_3(choose_1);
			}
			else
			{
				system("cls");
				medu_2();
			}
		}
	}
	if(choose_1==i+1)
	{
		system("cls");
		medu();
	}
	
	else if(choose_1==i+2)
	{
		exit(0);
	}

	else
	{
		cout<<"The choice you put is wrong,please input again.\n";
		Sleep(3000);
		system("cls");
		goto start2;
	}
}
//////////////С�˵�����///////////////
void medu();//��������
void medu_2();//��������
void medu_3(int x)
{
	int choose_3;
	choose_3=0;
start1:
	cout<<"�������CHOICES��������\n";	
	cout<<"*[1]: Modify the product name   *\n";
	cout<<"*[2]: Update the price          *\n";
	cout<<"*[3]: Back medu_2               *\n";
	cout<<"*[4]: Back medu                 *\n";
	cout<<"*[5]: Quit                      *\n";
	cout<<"*********************************\n";
	cout<<"please input your choice:\n";
	cin>>choose_3;
	switch(choose_3)
	{
		case 1:	system("cls");
				produuct[x]->change_name();
				goto start1;
				break;

		case 2:	system("cls");
				produuct[x]->change_price();
				goto start1;
				break;

		case 3:	system("cls");
				medu_2();
				break;

		case 4:	system("cls");
				medu();
				break;
		
		case 5:	exit(0);
				break;
		
		default:cout<<"The choice you put is wrong,please input again.\n";
				Sleep(3000);
				system("cls");
				goto start1;
	}
}
