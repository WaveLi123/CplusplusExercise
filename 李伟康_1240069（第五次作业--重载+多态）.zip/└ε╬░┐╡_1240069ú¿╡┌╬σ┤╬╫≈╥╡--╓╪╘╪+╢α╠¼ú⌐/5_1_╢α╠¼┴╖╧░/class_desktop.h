#include "class_product.h"
#include <string>
#include <iostream>
using namespace std;
class Desktop:public Product
{
private:
protected:
		string main_function;

public:
		void set_main_function()
		{
			cout<<"Please input the main_function of products:";
			getline(cin,main_function,'\n');
		}
/*
		void show_main_function()
		{
			cout<<"The main_function of the product:";
			cout<<main_function<<endl;
		}
*/
		void display()
		{
			Product::display();
			cout<<"The main_function of the product:";
			cout<<main_function<<endl;
		}
		virtual void show_adv_of_desktop()
		{
			cout<<"*****ADVDERTISING*****\n";
			cout<<"**********************\n";
			cout<<"�������ԣ��й�����!!!!\n";
			cout<<"**********************\n\n";
		}
};
