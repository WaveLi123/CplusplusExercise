#include "class_product.h"
#include <string>
#include <iostream>
using namespace std;
#ifndef D_b
#define D_b
class Ball:public Product
{
public:
	static void summary()
	{
		cout<<"The number of all the products is "<<count_number<<endl;
		cout<<"The price of all the products is "<<sum_price<<endl;
	}
};
#endif