#include "class_product.h"
#include <string>
#include <iostream>
using namespace std;
void Product::set_number()
{
	cout<<"Please input the number of products:";
	cin>>number;
}
/*
void Product::show_number()
{
	cout<<"The number of the product:";
	cout<<number<<endl;
}
*/
void Product::set_name()
{
	cout<<"Please input the name of products:";
	getline(cin,name,'\n');
}
/*
void Product::show_name()
{
	cout<<"The name of the product:";
	cout<<name<<endl;
}
*/
void Product::set_place()
{
	cout<<"Please input the place of products:";
	getline(cin,place,'\n');
}
/*
void Product::show_place()
{
	cout<<"The place of the product:";
	cout<<place<<endl;
}
*/
void Product::set_price()
{
	cout<<"Please input the price of products:";
	cin>>price;
}
/*
void Product::show_price()
{
	cout<<"The price of the product:";
	cout<<price<<endl;
}
*/
void Product::set_describtion()
{
	cout<<"Please input the describtion of products:";
	getline(cin,describtion,'\n');
}
/*
void Product::show_describtion()
{
	cout<<"The describtion of the product:";
	cout<<describtion<<endl;
}
*/
void Product::get_date(Date *date)
{
	cout<<"Please input the date of the product(hour:minute:second):\n";
	cout<<"hour:";
	cin>>date->hour;
	cout<<"minute:";
	cin>>date->minute;
	cout<<"seconds:";
	cin>>date->second;
}

void Product::show_date(Date *date)
{
	cout<<"The date of the product: ";
	cout<<date->hour<<":"<<date->minute<<":"<<date->second<<endl;
}

void Product::change_name()
{
	cout<<"The name of the product:";
	cout<<name<<endl;
	fflush(stdin);
	cout<<"Please input the new information:";
	getline(cin,name,'\n');
}

void Product::change_price()
{
	cout<<"The price of the product:";
	cout<<price<<endl;
	cout<<"Please input the new information:";
	cin>>price;
}
float Product::sum_of_price()
{
	sum_price=sum_price+price;
	return sum_price;
}
void Product::display()
{
	cout<<"The number of the product:";
	cout<<number<<endl;
	cout<<"The name of the product:";
	cout<<name<<endl;
	cout<<"The place of the product:";
	cout<<place<<endl;
	cout<<"The price of the product:";
	cout<<price<<endl;
	cout<<"The describtion of the product:";
	cout<<describtion<<endl;
}

