#include "class_product.h"
#include <string>
#include <iostream>
using namespace std;
class Laptop:public Product
{
private:
protected:
		string structure;
public:
		void set_structure()
		{
			cout<<"Please input the structure of products:";
			getline(cin,structure,'\n');
		}
/*
		void show_structure()
		{
			cout<<"The structure of the product:";
			cout<<structure<<endl;		
		}
*/
		void display()
		{
			Product::display();
			cout<<"The structure of the product:";
			cout<<structure<<endl;
		}
		virtual void show_adv_of_laptop()
		{
			cout<<"*****ADVDERTISING*****\n";
			cout<<"**********************\n";
			cout<<"Think pad,Think world!\n";
			cout<<"**********************\n\n";
		}
};
