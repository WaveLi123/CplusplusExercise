#include "class_ball.h"
#include <string>
#include <iostream>
using namespace std;
class Basketball:public Ball
{
protected:
	string material;

public:
	void set_material();
//	void show_material();
	void display()
	{
		Ball::display();
		cout<<"The material of the basketball:";
		cout<<material<<endl;
	}
	virtual void show_adv_of_basketball()
	{
		cout<<"********ADVDERTISING********\n";
		cout<<"****************************\n";
		cout<<"Where amamzing happens---NBA"<<endl;
		cout<<"****************************\n\n";
	}
};

