#include "StdAfx.h"
#include <iostream>
using namespace std;
class Time;
class Date
{
	friend void display(Date &,Time &);
private:
	int month;
	int day;
	int year;

public:
	Date(int m,int d,int y)
	{
		month=m;
		day=d;
		year=y;
	}
};
class Time
{
	friend void display(Date &,Time &);
private:
	int hour;
	int minute;
	int second;

public:
	Time(int h,int m,int s):hour(h),minute(m),second(s)
	{}
};
void display(Date &x,Time &y)
{
	cout<<x.month<<"/"<<x.day<<"/"<<x.year<<endl;
	cout<<y.hour<<":"<<y.minute<<":"<<y.second<<endl;
}
int main()
{
	Time t1(10,31,56);
	Date d1(4,13,2013);
	display(d1,t1);
	return 0;
}
