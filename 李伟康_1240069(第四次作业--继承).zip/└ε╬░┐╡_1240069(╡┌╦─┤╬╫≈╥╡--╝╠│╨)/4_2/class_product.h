//#include <afxcview.h>
//#include <afxdb.h>
#include <string>
#include <iostream>
using namespace std;
#ifndef D_p
#define D_p
class Date
{
	//��Ԫ��
	friend class Product;
	friend class Basketball;
	friend class Ball;
	friend class Football;
	friend class Desktop;
	friend class Laptop;
	
private:
	int hour;
	int minute;
	int second;
};

class Product
{
private:
	int number;
	float price;
	string name;
	string place;
	string describtion;
public:
	static int count_number;
	static float sum_price;
	void set_number();
	void show_number();
	void set_name();
	void show_name();
	void set_place();
	void show_place();
	void set_price();
	void show_price();
	void set_describtion();
	void show_describtion();
	void get_date(Date *);
	void show_date(Date *);
	void change_name();
	void change_price();
	float sum_of_price();
};
#endif
