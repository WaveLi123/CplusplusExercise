#include "class_ball.h"
#include <string>
#include <iostream>
using namespace std;
class Football:public Ball
{
protected:
	string size;

public:
	void set_size();
	void show_size();
};
