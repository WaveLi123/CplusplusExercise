#include "class_basketball.h"
#include <string>
#include <iostream>
using namespace std;
void Basketball::set_material()
{
	cout<<"Please input the material of the basketball:";
	getline(cin,material,'\n');
}
void Basketball::show_material()
{
	cout<<"The material of the basketball:";
	cout<<material<<endl;
}
