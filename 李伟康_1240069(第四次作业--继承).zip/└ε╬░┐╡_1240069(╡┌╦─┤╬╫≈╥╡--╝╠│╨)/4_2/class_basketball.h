#include "class_ball.h"
#include <string>
#include <iostream>
using namespace std;
class Basketball:public Ball
{
protected:
	string material;

public:
	void set_material();
	void show_material();
};

