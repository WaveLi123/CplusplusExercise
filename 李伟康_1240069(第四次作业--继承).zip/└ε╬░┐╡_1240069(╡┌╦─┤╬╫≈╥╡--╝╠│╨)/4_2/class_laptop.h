#include "class_product.h"
#include <string>
#include <iostream>
using namespace std;
class Laptop:public Product
{
private:
protected:
		string structure;
public:
		void set_structure()
		{
			cout<<"Please input the structure of products:";
			getline(cin,structure,'\n');
		}
		void show_structure()
		{
			cout<<"The structure of the product:";
			cout<<structure<<endl;		
		}
};
