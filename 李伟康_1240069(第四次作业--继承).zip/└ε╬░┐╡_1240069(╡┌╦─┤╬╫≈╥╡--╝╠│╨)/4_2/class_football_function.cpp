#include "class_football.h"
#include <string>
#include <iostream>
using namespace std;
void Football::set_size()
{
	cout<<"Please input the size of the football(R):";
	getline(cin,size,'\n');
}
void Football::show_size()
{
	cout<<"The size of the football:";
	cout<<size<<endl;
}
