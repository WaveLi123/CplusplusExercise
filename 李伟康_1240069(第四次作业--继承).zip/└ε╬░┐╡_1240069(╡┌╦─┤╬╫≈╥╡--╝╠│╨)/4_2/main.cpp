#include "class_product.h"
#include "class_basketball.h"
#include "class_football.h"
#include "class_desktop.h"
#include "class_laptop.h"
#include <iostream>
#include <windows.h>
#include <string>
using namespace std;

//��̬��Ա�ĳ�ʼ��
int Product::count_number=0;
float Product::sum_price=0.0;

//����ȫ�ֱ���
int i=0;
int count_basketball=0;
int count_football=0;
int count_desktop=0;
int count_laptop=0;
Date *date[1000];
Product *product[1000];
Basketball *basketball[1000];
Football *football[1000];
Desktop *desktop[1000];
Laptop *laptop[1000];

//��������
int system(const char *string);
void medu();

int main()
{
	medu ();
	int j;
	for(j=1;j<=i;j++)
	{
		delete product[j];
		delete date[j];
	}
	return 0;
}

/////////////////////////////////////���˵���������/////////////////////////////////////
//��������
void medu_2();
void add();

void medu()
{
	char choose;
	choose=0;
start:
	cout<<"������ONLINE_SHOP�������\n";
	cout<<"�������CHOICES��������\n";
	cout<<"*[A]: Add a product             *\n";
	cout<<"*[D]: Display all products      *\n";
	cout<<"*[S]: Summary                   *\n";
	cout<<"*[Q]: Quit                      *\n";
	cout<<"*********************************\n";
	cout<<"Please input your chice:\n";
	cin>>choose;

	if(choose=='a'||choose=='A')
	{
		system("cls");
		add();
	}

	else if(choose=='s'||choose=='S')
	{
		system("cls");
		cout<<"The number of products:"<<endl;
		cout<<i<<endl;
		Sleep(2000);
		system("cls");
		medu();
	}

	else if(choose=='d'||choose=='D')
	{
		system("cls");
		medu_2();
	}

	else if(choose=='Q'||choose=='q')
	{
		exit(0);
	}

	else 
	{
		cout<<"The choice you put is wrong,please input again.\n";
		Sleep(3000);
		system("cls");
		goto start;
	}
}

void add()
{
	int choose_add=0;
	cout<<"Please input the kind of product:\n";
	cout<<"�������KINDS OF PRODUCTS ��������\n";
	cout<<"1.Balls.                                  ��\n";
	cout<<"2.Electrics.                              ��\n";
	cout<<"3.Back medu.                              ��\n";
	cout<<"4.Quit.                                   ��\n";
	cout<<"�����������������������\n";
	cin>>choose_add;
	
//�����Ʒ�����Ϣ
	char c;
	c='n';
	int choose_add2=0;
	if(choose_add==1)
	{
		system("cls");
		cout<<"Please input the kind of product:\n";
		cout<<"�������KINDS OF BALLS��������\n";
		cout<<"1.Basketball.                         ��\n";
		cout<<"2.Football.                           ��\n";
		cout<<"3.Back medu_2.                        ��\n";
		cout<<"4.Back medu.                          ��\n";
		cout<<"5.Quit.                               ��\n";
		cout<<"���������������������\n";
		cin>>choose_add2;
		switch(choose_add2)
		{
		case 1:	system("cls");
				while(c!='y'&&c!='Y')
				{
					++i;
					cout<<"***ע�������ʽһ��Ҫ��ȷ***\n";
					cout<<"The product of basketball"<<" ["<<++count_basketball<<"]"<<"'s information:\n";
					product[i]=new Product;
					basketball[count_basketball]=new Basketball;
					date[count_basketball]=new Date;
	  				basketball[count_basketball]->set_number();
					basketball[count_basketball]->set_price();
					fflush(stdin);
					basketball[count_basketball]->set_name();
					basketball[count_basketball]->set_place();
					basketball[count_basketball]->set_material();
					basketball[count_basketball]->set_describtion();
					fflush(stdin);
					basketball[count_basketball]->get_date(date[count_basketball]);
					cout<<endl<<endl;
					cout<<"Do you want to quit?(y/n)\n";
					cin>>c;
					system("cls");
				}
				main();
				break;
		
		case 2:	system("cls");
				while(c!='y'&&c!='Y')
				{
					++i;
					cout<<"***ע�������ʽһ��Ҫ��ȷ***\n";
					cout<<"The product of football"<<" ["<<++count_football<<"]"<<"'s information:\n";
					product[i]=new Product;
					football[count_football]=new Football;
					date[count_football]=new Date;
	  				football[count_football]->set_number();
					football[count_football]->set_price();
					fflush(stdin);
					football[count_football]->set_name();
					football[count_football]->set_place();
					football[count_football]->set_size();
					football[count_football]->set_describtion();
					fflush(stdin);
					football[count_football]->get_date(date[count_football]);
					cout<<endl<<endl;
					cout<<"Do you want to quit?(y/n)\n";
					cin>>c;
					system("cls");
				}

				main();
				break;
		case 3:	system("cls");
				add();
		
		case 4:	system("cls");
				main();	

		case 5:	exit(0);

		}
	}
	if(choose_add==2)
	{
		system("cls");
		cout<<"Please input the kind of product:\n";
		cout<<"������KINDS OF ELECTRICS�������\n";
		cout<<"1.Desktop.                            ��\n";
		cout<<"2.Laptop.                             ��\n";
		cout<<"3.Back medu_2.                        ��\n";
		cout<<"4.Back medu.                          ��\n";
		cout<<"5.Quit.                               ��\n";
		cout<<"���������������������\n";
		cin>>choose_add2;
		switch(choose_add2)
		{
		case 1:	system("cls");
				while(c!='y'&&c!='Y')
				{
					++i;
					cout<<"***ע�������ʽһ��Ҫ��ȷ***\n";
					cout<<"The product of desktop"<<" ["<<++count_desktop<<"]"<<"'s information:\n";
					product[i]=new Product;
					desktop[count_desktop]=new Desktop;
					date[count_desktop]=new Date;
	  				desktop[count_desktop]->set_number();
					desktop[count_desktop]->set_price();
					fflush(stdin);
					desktop[count_desktop]->set_name();
					desktop[count_desktop]->set_place();
					desktop[count_desktop]->set_main_function();
					desktop[count_desktop]->set_describtion();
					fflush(stdin);
					desktop[count_desktop]->get_date(date[count_desktop]);
					cout<<endl<<endl;
					cout<<"Do you want to quit?(y/n)\n";
					cin>>c;
					system("cls");
				}
				main();
				break;
		
		case 2:	system("cls");
				while(c!='y'&&c!='Y')
				{
					++i;
					cout<<"***ע�������ʽһ��Ҫ��ȷ***\n";
					cout<<"The product of laptop"<<" ["<<++count_laptop<<"]"<<"'s information:\n";
					product[i]=new Product;
					laptop[count_laptop]=new Laptop;
					date[count_laptop]=new Date;
	  				laptop[count_laptop]->set_number();
					football[count_laptop]->set_price();
					fflush(stdin);
					laptop[count_laptop]->set_name();
					laptop[count_laptop]->set_place();
					laptop[count_laptop]->set_structure();
					laptop[count_laptop]->set_describtion();
					fflush(stdin);
					laptop[count_football]->get_date(date[count_laptop]);
					cout<<endl<<endl;
					cout<<"Do you want to quit?(y/n)\n";
					cin>>c;
					system("cls");
				}

				main();
				break;
		case 3:	system("cls");
				add();
		
		case 4:	system("cls");
				main();	

		case 5:	exit(0);

		}
	}
	if(choose_add==3)
	{
		system("cls");
		main();
	}
	if(choose_add==4)
	{
		system("cls");
		exit(0);
	}

}
//////////////////////////////////////////���˵�����///////////////////////////////////////////
void medu_3(int x);//��������
void medu();//��������
void medu_2()
{
	int j_2;
	int choose_1=0;
	int choose_1_1=0;
	char choose_2=0;

start2:
	cout<<"��PRODUCTS'S INFORMATION��\n";
	cout<<"1.Basketball.            *\n";
	cout<<"2.Football.              *\n";
	cout<<"3.Desktop.               *\n";
	cout<<"4.Laptop.                *\n";
	cout<<"5.Back medu.             *\n";
	cout<<"6.Quit.                  *\n";
	cout<<"**************************\n";
	cout<<"Please input the number of choosing:\n";
	cin>>choose_1;

start3:
	switch(choose_1)
	{
	case 1:	system("cls");
			cout<<"��PRODUCTS OF BASKETBALL INFORMATION��\n";
			for(j_2=1;j_2<=count_basketball;j_2++)
			{
				cout<<"*"<<j_2<<".product of basketball["<<j_2<<"]          *"<<endl;
			}
			cout<<"*"<<count_basketball+1<<".Back medu_2                       *"<<endl;
			cout<<"*"<<count_basketball+2<<".Back medu                         *"<<endl;
			cout<<"*"<<count_basketball+3<<".Quit                              *"<<endl;
			cout<<"**************************************\n\n";
			cout<<"Please input the number of choosing:\n";
			cin>>choose_1_1;

			for(j_2=1;j_2<=count_basketball;j_2++)
			{
				if(choose_1_1==j_2)
				{
					system("cls");
					cout<<"������Product of basketball["<<j_2<<"]'s information ������\n";
					basketball[j_2]->show_number();
					basketball[j_2]->show_price();
					basketball[j_2]->show_name();
					basketball[j_2]->show_place();
					basketball[j_2]->show_describtion();
					basketball[j_2]->show_date(date[j_2]);
					cout<<"******************************************\n\n";
				}
			}
			if(choose_1_1==count_basketball+1)
			{
				system("cls");
				medu_2();
			}
			if(choose_1_1==count_basketball+2)
			{
				system("cls");
				medu();
			}
			if(choose_1_1==count_basketball+3)
			{
				system("cls");
				exit(0);
			}

			cout<<"Do you want to change the news of the product?(y/n)\n";
			cin>>choose_2;

			if(choose_2=='y'||choose_2=='Y')
			{
				system("cls");
				//����ӳ��(->Product)
				product[choose_1_1]=basketball[choose_1_1];
				medu_3(choose_1_1);
			}
			else
			{
				system("cls");
				goto start3;
			}
		
			break;

	case 2:	system("cls");
			cout<<"��PRODUCTS OF FOOTBALL INFORMATION��\n";
			for(j_2=1;j_2<=count_football;j_2++)
			{
				cout<<"*"<<j_2<<".product of football["<<j_2<<"]          *"<<endl;
			}
			cout<<"*"<<count_football+1<<".Back medu_2                     *"<<endl;
			cout<<"*"<<count_football+2<<".Back medu                       *"<<endl;
			cout<<"*"<<count_football+3<<".Quit                            *"<<endl;
			cout<<"************************************\n\n";
			cout<<"Please input the number of choosing:\n";
			cin>>choose_1_1;

			for(j_2=1;j_2<=count_football;j_2++)
			{
				if(choose_1_1==j_2)
				{
					system("cls");
					cout<<"������Product of football["<<j_2<<"]'s information ������\n";
					football[j_2]->show_number();
					football[j_2]->show_price();
					football[j_2]->show_name();
					football[j_2]->show_place();
					football[j_2]->show_describtion();
					football[j_2]->show_date(date[j_2]);
					cout<<"******************************************\n\n";
				}
			}
			if(choose_1_1==count_football+1)
			{
				system("cls");
				medu_2();
			}
			if(choose_1_1==count_football+2)
			{
				system("cls");
				medu();
			}
			if(choose_1_1==count_football+3)
			{
				system("cls");
				exit(0);
			}

			cout<<"Do you want to change the news of the product?(y/n)\n";
			cin>>choose_2;

			if(choose_2=='y'||choose_2=='Y')
			{
				system("cls");
				//����ӳ��(->Product)
				product[choose_1_1]=football[choose_1_1];
				medu_3(choose_1_1);
			}
			else
			{
				system("cls");
				goto start3;
			}
		
			break;

	case 3:	system("cls");
			cout<<"��PRODUCTS OF DESKTOP INFORMATION��\n";
			for(j_2=1;j_2<=count_desktop;j_2++)
			{
				cout<<"*"<<j_2<<".product of desktop["<<j_2<<"]          *"<<endl;
			}
			cout<<"*"<<count_desktop+1<<".Back medu_2                     *"<<endl;
			cout<<"*"<<count_desktop+2<<".Back medu                       *"<<endl;
			cout<<"*"<<count_desktop+3<<".Quit                            *"<<endl;
			cout<<"************************************\n\n";
			cout<<"Please input the number of choosing:\n";
			cin>>choose_1_1;

			for(j_2=1;j_2<=count_desktop;j_2++)
			{
				if(choose_1_1==j_2)
				{
					system("cls");
					cout<<"������Product of desktop["<<j_2<<"]'s information ������\n";
					desktop[j_2]->show_number();
					desktop[j_2]->show_price();
					desktop[j_2]->show_name();
					desktop[j_2]->show_place();
					desktop[j_2]->show_describtion();
					desktop[j_2]->show_date(date[j_2]);
					cout<<"******************************************\n\n";
				}
			}
			if(choose_1_1==count_desktop+1)
			{
				system("cls");
				medu_2();
			}
			if(choose_1_1==count_desktop+2)
			{
				system("cls");
				medu();
			}
			if(choose_1_1==count_desktop+3)
			{
				system("cls");
				exit(0);
			}

			cout<<"Do you want to change the news of the product?(y/n)\n";
			cin>>choose_2;

			if(choose_2=='y'||choose_2=='Y')
			{
				system("cls");
				//����ӳ��(->Product)
				product[choose_1_1]=desktop[choose_1_1];
				medu_3(choose_1_1);
			}
			else
			{
				system("cls");
				goto start3;
			}
		
			break;
	case 4:	system("cls");
			cout<<"��PRODUCTS OF LAPTOP INFORMATION��\n";
			for(j_2=1;j_2<=count_laptop;j_2++)
			{
				cout<<"*"<<j_2<<".product of laptop["<<j_2<<"]          *"<<endl;
			}
			cout<<"*"<<count_laptop+1<<".Back medu_2                     *"<<endl;
			cout<<"*"<<count_laptop+2<<".Back medu                       *"<<endl;
			cout<<"*"<<count_laptop+3<<".Quit                            *"<<endl;
			cout<<"************************************\n\n";
			cout<<"Please input the number of choosing:\n";
			cin>>choose_1_1;

			for(j_2=1;j_2<=count_laptop;j_2++)
			{
				if(choose_1_1==j_2)
				{
					system("cls");
					cout<<"������Product of laptop["<<j_2<<"]'s information ������\n";
					laptop[j_2]->show_number();
					laptop[j_2]->show_price();
					laptop[j_2]->show_name();
					laptop[j_2]->show_place();
					laptop[j_2]->show_describtion();
					laptop[j_2]->show_date(date[j_2]);
					cout<<"******************************************\n\n";
				}
			}
			if(choose_1_1==count_laptop+1)
			{
				system("cls");
				medu_2();
			}
			if(choose_1_1==count_laptop+2)
			{
				system("cls");
				medu();
			}
			if(choose_1_1==count_laptop+3)
			{
				system("cls");
				exit(0);
			}

			cout<<"Do you want to change the news of the product?(y/n)\n";
			cin>>choose_2;

			if(choose_2=='y'||choose_2=='Y')
			{
				system("cls");
				//����ӳ��(->Product)
				product[choose_1_1]=laptop[choose_1_1];
				medu_3(choose_1_1);
			}
			else
			{
				system("cls");
				goto start3;
			}
			
			break;

	case 5:	system("cls");
			medu();
			break;

	case 6:	system("cls");
			exit(0);
			break;
	
	default:cout<<"The choice you put is wrong,please input again.\n";
			Sleep(3000);
			system("cls");
			goto start2;
			
	}
}
//////////////С�˵�����///////////////
void medu();//��������
void medu_2();//��������
void medu_3(int x)
{
	int choose_3;
	choose_3=0;
start1:
	cout<<"�������CHOICES��������\n";	
	cout<<"*[1]: Modify the product name   *\n";
	cout<<"*[2]: Update the price          *\n";
	cout<<"*[3]: Back medu_2               *\n";
	cout<<"*[4]: Back medu                 *\n";
	cout<<"*[5]: Quit                      *\n";
	cout<<"*********************************\n";
	cout<<"please input your choice:\n";
	cin>>choose_3;
	switch(choose_3)
	{
		case 1:	system("cls");
				product[x]->change_name();
				goto start1;
				break;

		case 2:	system("cls");
				product[x]->change_price();
				goto start1;
				break;

		case 3:	system("cls");
				medu_2();
				break;

		case 4:	system("cls");
				medu();
				break;
		
		case 5:	exit(0);
				break;
		
		default:cout<<"The choice you put is wrong,please input again.\n";
				Sleep(3000);
				system("cls");
				goto start1;
	}
}




